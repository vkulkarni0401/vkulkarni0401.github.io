USE CustomerServiceBI;
GO

CREATE OR ALTER VIEW dbo.vw_MonthlyKPI
AS
WITH order_month AS (
    SELECT
        DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1) AS month_start,
        SUM(CASE WHEN order_status = 'Delivered' THEN order_value ELSE 0 END) AS revenue,
        SUM(CASE WHEN order_status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_orders,
        SUM(CASE WHEN order_status = 'Delivered' AND on_time_flag = 1 THEN 1 ELSE 0 END) AS on_time_orders,
        COUNT(DISTINCT CASE WHEN order_status = 'Delivered' THEN customer_id END) AS active_customers
    FROM dbo.FactOrder
    GROUP BY DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1)
),
customer_month AS (
    SELECT DISTINCT
        DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1) AS month_start,
        customer_id
    FROM dbo.FactOrder
    WHERE order_status = 'Delivered'
),
month_list AS (
    SELECT month_start FROM order_month
),
customer_transition AS (
    SELECT
        m.month_start,
        p.customer_id,
        CASE WHEN c.customer_id IS NOT NULL THEN 1 ELSE 0 END AS retained_flag,
        CASE WHEN c.customer_id IS NULL THEN 1 ELSE 0 END AS churned_flag
    FROM month_list m
    INNER JOIN customer_month p
        ON p.month_start = DATEADD(MONTH, -1, m.month_start)
    LEFT JOIN customer_month c
        ON c.month_start = m.month_start
       AND c.customer_id = p.customer_id
),
customer_kpi AS (
    SELECT
        month_start,
        COUNT(*) AS previous_active_customers,
        SUM(retained_flag) AS retained_customers,
        SUM(churned_flag) AS churned_customers
    FROM customer_transition
    GROUP BY month_start
),
monthly_base AS (
    SELECT
        o.month_start,
        o.revenue,
        o.delivered_orders,
        o.on_time_orders,
        CAST(o.on_time_orders * 1.0 / NULLIF(o.delivered_orders, 0) AS decimal(18,4)) AS service_level,
        o.active_customers,
        c.previous_active_customers,
        c.retained_customers,
        c.churned_customers,
        CAST(c.retained_customers * 1.0 / NULLIF(c.previous_active_customers, 0) AS decimal(18,4)) AS retention_rate,
        CAST(c.churned_customers * 1.0 / NULLIF(c.previous_active_customers, 0) AS decimal(18,4)) AS churn_rate
    FROM order_month o
    LEFT JOIN customer_kpi c ON c.month_start = o.month_start
),
period_comparison AS (
    SELECT
        *,
        LAG(revenue, 1) OVER (ORDER BY month_start) AS previous_month_revenue,
        LAG(revenue, 12) OVER (ORDER BY month_start) AS prior_year_revenue
    FROM monthly_base
)
SELECT
    month_start,
    revenue,
    delivered_orders,
    on_time_orders,
    service_level,
    active_customers,
    previous_active_customers,
    retained_customers,
    churned_customers,
    retention_rate,
    churn_rate,
    CAST(revenue / NULLIF(previous_month_revenue, 0) - 1 AS decimal(18,4)) AS mom_revenue_growth,
    CAST(revenue / NULLIF(prior_year_revenue, 0) - 1 AS decimal(18,4)) AS yoy_revenue_growth,
    SUM(revenue) OVER (
        PARTITION BY YEAR(month_start)
        ORDER BY month_start
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS ytd_revenue
FROM period_comparison;
GO

-- Monthly KPI trend
SELECT *
FROM dbo.vw_MonthlyKPI
ORDER BY month_start;
GO

-- Latest-month scorecard with target status
WITH latest AS (
    SELECT TOP (1) *
    FROM dbo.vw_MonthlyKPI
    ORDER BY month_start DESC
),
scorecard AS (
    SELECT month_start, 'Service Level' AS metric, service_level AS actual_value FROM latest
    UNION ALL SELECT month_start, 'Retention Rate', retention_rate FROM latest
    UNION ALL SELECT month_start, 'Churn Rate', churn_rate FROM latest
    UNION ALL SELECT month_start, 'MoM Revenue Growth', mom_revenue_growth FROM latest
    UNION ALL SELECT month_start, 'YoY Revenue Growth', yoy_revenue_growth FROM latest
)
SELECT
    s.month_start,
    s.metric,
    s.actual_value,
    t.target_value,
    s.actual_value - t.target_value AS variance_to_target,
    CASE
        WHEN t.comparison = '>=' AND s.actual_value >= t.target_value THEN 'On Target'
        WHEN t.comparison = '<=' AND s.actual_value <= t.target_value THEN 'On Target'
        WHEN s.actual_value IS NULL THEN 'Not Available'
        ELSE 'Off Target'
    END AS performance_status
FROM scorecard s
INNER JOIN dbo.KPITarget t ON t.metric = s.metric
ORDER BY s.metric;
GO

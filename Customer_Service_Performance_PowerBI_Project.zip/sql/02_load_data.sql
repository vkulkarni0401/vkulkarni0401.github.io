/*
Update @DataFolder to the local folder containing the CSV files.
SQL Server service account must have read access to that folder.
*/

USE CustomerServiceBI;
GO

DECLARE @DataFolder nvarchar(4000) = N'C:\BI_Project\data\';
DECLARE @Sql nvarchar(max);

SET @Sql = N'BULK INSERT dbo.DimCustomer FROM ''' + @DataFolder + N'customers.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, FIELDQUOTE = ''"'', TABLOCK);';
EXEC sys.sp_executesql @Sql;

SET @Sql = N'BULK INSERT dbo.DimWarehouse FROM ''' + @DataFolder + N'warehouses.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, FIELDQUOTE = ''"'', TABLOCK);';
EXEC sys.sp_executesql @Sql;

SET @Sql = N'BULK INSERT dbo.DimCarrier FROM ''' + @DataFolder + N'carriers.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, FIELDQUOTE = ''"'', TABLOCK);';
EXEC sys.sp_executesql @Sql;

SET @Sql = N'BULK INSERT dbo.FactOrder FROM ''' + @DataFolder + N'orders.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, FIELDQUOTE = ''"'', TABLOCK, KEEPNULLS);';
EXEC sys.sp_executesql @Sql;

SET @Sql = N'BULK INSERT dbo.KPITarget FROM ''' + @DataFolder + N'kpi_targets.csv'' WITH (FORMAT = ''CSV'', FIRSTROW = 2, FIELDQUOTE = ''"'', TABLOCK);';
EXEC sys.sp_executesql @Sql;
GO

SELECT 'Customers' AS table_name, COUNT(*) AS row_count FROM dbo.DimCustomer
UNION ALL SELECT 'Warehouses', COUNT(*) FROM dbo.DimWarehouse
UNION ALL SELECT 'Carriers', COUNT(*) FROM dbo.DimCarrier
UNION ALL SELECT 'Orders', COUNT(*) FROM dbo.FactOrder
UNION ALL SELECT 'KPI Targets', COUNT(*) FROM dbo.KPITarget;
GO

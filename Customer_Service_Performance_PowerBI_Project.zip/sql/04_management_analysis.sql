USE CustomerServiceBI;
GO

-- Service level and revenue by warehouse
SELECT
    w.warehouse_name,
    COUNT(*) AS delivered_orders,
    SUM(o.order_value) AS revenue,
    CAST(AVG(CAST(o.on_time_flag AS decimal(18,4))) AS decimal(18,4)) AS service_level,
    AVG(CAST(o.satisfaction_score AS decimal(18,2))) AS average_satisfaction
FROM dbo.FactOrder o
INNER JOIN dbo.DimWarehouse w ON w.warehouse_id = o.warehouse_id
WHERE o.order_status = 'Delivered'
GROUP BY w.warehouse_name
ORDER BY service_level;
GO

-- Carrier performance and late-order volume
SELECT
    c.carrier_name,
    COUNT(*) AS delivered_orders,
    SUM(CASE WHEN o.on_time_flag = 0 THEN 1 ELSE 0 END) AS late_orders,
    CAST(AVG(CAST(o.on_time_flag AS decimal(18,4))) AS decimal(18,4)) AS service_level,
    SUM(o.order_value) AS delivered_revenue
FROM dbo.FactOrder o
INNER JOIN dbo.DimCarrier c ON c.carrier_id = o.carrier_id
WHERE o.order_status = 'Delivered'
GROUP BY c.carrier_name
ORDER BY service_level;
GO

-- Root causes of late delivery
SELECT
    late_reason,
    COUNT(*) AS late_orders,
    CAST(COUNT(*) * 1.0 / SUM(COUNT(*)) OVER () AS decimal(18,4)) AS share_of_late_orders,
    SUM(order_value) AS revenue_affected
FROM dbo.FactOrder
WHERE order_status = 'Delivered'
  AND on_time_flag = 0
GROUP BY late_reason
ORDER BY late_orders DESC;
GO

-- Revenue and service performance by customer segment
SELECT
    c.segment,
    COUNT(DISTINCT o.customer_id) AS active_customers,
    COUNT(*) AS delivered_orders,
    SUM(o.order_value) AS revenue,
    CAST(AVG(CAST(o.on_time_flag AS decimal(18,4))) AS decimal(18,4)) AS service_level,
    AVG(CAST(o.satisfaction_score AS decimal(18,2))) AS average_satisfaction
FROM dbo.FactOrder o
INNER JOIN dbo.DimCustomer c ON c.customer_id = o.customer_id
WHERE o.order_status = 'Delivered'
GROUP BY c.segment
ORDER BY revenue DESC;
GO

-- Customers active last month but not in the latest month
WITH latest_month AS (
    SELECT MAX(DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1)) AS month_start
    FROM dbo.FactOrder
),
customer_month AS (
    SELECT DISTINCT
        DATEFROMPARTS(YEAR(order_date), MONTH(order_date), 1) AS month_start,
        customer_id
    FROM dbo.FactOrder
    WHERE order_status = 'Delivered'
),
churned AS (
    SELECT p.customer_id
    FROM latest_month m
    INNER JOIN customer_month p ON p.month_start = DATEADD(MONTH, -1, m.month_start)
    LEFT JOIN customer_month c ON c.month_start = m.month_start AND c.customer_id = p.customer_id
    WHERE c.customer_id IS NULL
)
SELECT
    d.customer_id,
    d.customer_name,
    d.segment,
    d.region,
    d.primary_service,
    SUM(CASE WHEN o.order_status = 'Delivered' THEN o.order_value ELSE 0 END) AS lifetime_revenue
FROM churned x
INNER JOIN dbo.DimCustomer d ON d.customer_id = x.customer_id
LEFT JOIN dbo.FactOrder o ON o.customer_id = d.customer_id
GROUP BY d.customer_id, d.customer_name, d.segment, d.region, d.primary_service
ORDER BY lifetime_revenue DESC;
GO

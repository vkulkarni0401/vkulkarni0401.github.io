/*
Customer Service Performance BI Analytics
SQL Server schema
*/

IF DB_ID('CustomerServiceBI') IS NULL
    CREATE DATABASE CustomerServiceBI;
GO

USE CustomerServiceBI;
GO

DROP TABLE IF EXISTS dbo.KPITarget;
DROP TABLE IF EXISTS dbo.FactOrder;
DROP TABLE IF EXISTS dbo.DimCarrier;
DROP TABLE IF EXISTS dbo.DimWarehouse;
DROP TABLE IF EXISTS dbo.DimCustomer;
GO

CREATE TABLE dbo.DimCustomer (
    customer_id          varchar(10)  NOT NULL PRIMARY KEY,
    customer_name        varchar(100) NOT NULL,
    signup_date          date         NOT NULL,
    segment              varchar(30)  NOT NULL,
    region               varchar(30)  NOT NULL,
    acquisition_channel  varchar(30)  NOT NULL,
    primary_service      varchar(30)  NOT NULL,
    warehouse_id         varchar(10)  NOT NULL
);

CREATE TABLE dbo.DimWarehouse (
    warehouse_id    varchar(10)  NOT NULL PRIMARY KEY,
    warehouse_name  varchar(100) NOT NULL,
    province        varchar(40)  NOT NULL,
    capacity_tier   varchar(20)  NOT NULL
);

CREATE TABLE dbo.DimCarrier (
    carrier_id    varchar(10)  NOT NULL PRIMARY KEY,
    carrier_name  varchar(100) NOT NULL,
    mode          varchar(30)  NOT NULL
);

CREATE TABLE dbo.FactOrder (
    order_id            varchar(12)   NOT NULL PRIMARY KEY,
    customer_id         varchar(10)   NOT NULL,
    order_date          date          NOT NULL,
    promised_date       date          NOT NULL,
    delivery_date       date          NULL,
    order_status        varchar(20)   NOT NULL,
    service_type        varchar(30)   NOT NULL,
    warehouse_id        varchar(10)   NOT NULL,
    carrier_id          varchar(10)   NOT NULL,
    units               int           NOT NULL,
    order_value         decimal(18,2) NOT NULL,
    delivery_cost       decimal(18,2) NOT NULL,
    on_time_flag        tinyint       NULL,
    late_reason         varchar(40)   NOT NULL,
    satisfaction_score  tinyint       NULL,
    CONSTRAINT FK_FactOrder_Customer FOREIGN KEY (customer_id) REFERENCES dbo.DimCustomer(customer_id),
    CONSTRAINT FK_FactOrder_Warehouse FOREIGN KEY (warehouse_id) REFERENCES dbo.DimWarehouse(warehouse_id),
    CONSTRAINT FK_FactOrder_Carrier FOREIGN KEY (carrier_id) REFERENCES dbo.DimCarrier(carrier_id)
);

CREATE TABLE dbo.KPITarget (
    metric        varchar(50)    NOT NULL PRIMARY KEY,
    target_value  decimal(18,4)  NOT NULL,
    comparison    varchar(2)     NOT NULL,
    cadence       varchar(20)    NOT NULL,
    definition    varchar(500)   NOT NULL
);

CREATE INDEX IX_FactOrder_OrderDate ON dbo.FactOrder(order_date);
CREATE INDEX IX_FactOrder_CustomerMonth ON dbo.FactOrder(customer_id, order_date);
CREATE INDEX IX_FactOrder_Operations ON dbo.FactOrder(warehouse_id, carrier_id, service_type, order_date);
GO

# Customer Service Performance BI Analytics

This portfolio project demonstrates end-to-end Business Intelligence skills using a fictional Canadian B2B logistics company. It combines a realistic synthetic dataset, SQL Server analysis, KPI target logic, Power BI DAX measures, and a dashboard layout prototype.

## Business objective

Leadership needs a monthly view of customer growth and operational execution. The analysis answers six questions:

1. Are orders being delivered within the promised service commitment?
2. Are active customers remaining active from month to month?
3. How quickly is the customer base churning?
4. Is revenue improving versus the previous month and the same month last year?
5. How much revenue has accumulated year to date?
6. Which warehouses, carriers, regions, service types, and late-delivery reasons explain performance variation?

## KPI scorecard

| KPI | Definition | Portfolio target |
| --- | --- | ---: |
| Service level | On-time delivered orders / delivered orders | >= 95% |
| Retention rate | Prior-month active customers retained in the current month / prior-month active customers | >= 90% |
| Churn rate | Prior-month active customers not active in the current month / prior-month active customers | <= 10% |
| MoM revenue growth | Current-month delivered revenue / previous-month delivered revenue - 1 | >= 2% |
| YoY revenue growth | Current-month delivered revenue / same month last year - 1 | >= 8% |
| YTD revenue | Delivered revenue accumulated from January through the reporting month | Track versus plan |

An active customer is a customer with at least one delivered order in the month. Retention and churn use the prior month's active-customer population as the denominator.

## September 2025 executive readout

| KPI | Result | Interpretation |
| --- | ---: | --- |
| Service level | 95.7% | Above the 95% target |
| Retention rate | 91.0% | Above the 90% target |
| Churn rate | 9.0% | Below the 10% maximum |
| MoM revenue growth | -9.1% | Below the 2% growth target |
| YoY revenue growth | -13.0% | Below the 8% growth target |
| 2025 YTD revenue | $6.07M | Revenue accumulated through September |

Operational service and customer retention met target, but monthly and year-over-year revenue declined. The next analysis should separate revenue loss caused by fewer active customers from changes in order frequency and revenue per active customer.

## Repository structure

```text
data/
  customers.csv
  orders.csv
  warehouses.csv
  carriers.csv
  kpi_targets.csv
  monthly_kpi_results.csv
sql/
  01_create_schema.sql
  02_load_data.sql
  03_kpi_queries.sql
  04_management_analysis.sql
powerbi/
  DAX_Measures.dax
  Dashboard_Build_Guide.md
  Power_Query_M_Code.pq
  Star_Schema.md
docs/
  data_dictionary.md
  kpi_definitions.md
excel/
  Business_Intelligence_KPI_Dashboard.xlsx
assets/
  business-intelligence-dashboard.png
```

## Run the SQL project

1. Open SQL Server Management Studio.
2. Run `sql/01_create_schema.sql`.
3. Update the folder path in `sql/02_load_data.sql`, then run it.
4. Run `sql/03_kpi_queries.sql` to create the monthly KPI view and scorecard query.
5. Run `sql/04_management_analysis.sql` for driver and root-cause analysis.

## Build the Power BI report

1. Open Power BI Desktop and select **Get data > Text/CSV**.
2. Import `customers.csv`, `orders.csv`, `warehouses.csv`, `carriers.csv`, and `kpi_targets.csv`.
3. Apply the data types listed in `powerbi/Power_Query_M_Code.pq`, or copy the included queries into the Advanced Editor.
4. Create the calendar table and relationships in `powerbi/Star_Schema.md`.
5. Add the measures from `powerbi/DAX_Measures.dax`.
6. Build the four report pages described in `powerbi/Dashboard_Build_Guide.md`.

The Excel workbook provides a finished KPI layout prototype and independently calculated monthly results for reconciliation. The portfolio project itself is designed for Power BI.

## Power BI model

Recommended relationships:

- `DimCustomer[customer_id]` 1:* `FactOrder[customer_id]`
- `DimWarehouse[warehouse_id]` 1:* `FactOrder[warehouse_id]`
- `DimCarrier[carrier_id]` 1:* `FactOrder[carrier_id]`
- A calendar table 1:* `FactOrder[order_date]`

Recommended report pages:

1. Leadership scorecard: service level, retention, churn, revenue, MoM, YoY, and YTD.
2. Customer performance: retention and churn by segment, region, and acquisition channel.
3. Service operations: on-time performance by warehouse, carrier, service type, and late reason.
4. Front-line action list: customers at risk, lanes below target, and largest revenue variances.

## Portfolio value

This project demonstrates SQL data modeling, window functions, period-over-period analysis, customer cohort logic, KPI scorecards, target variance, root-cause analysis, dashboard design, and business communication.

## Resume-ready bullets

- Built a SQL Server and Excel Business Intelligence solution analyzing customer revenue, service performance, retention, and churn across a multi-year B2B logistics dataset.
- Developed reusable SQL views for service level, monthly retention, churn, MoM, YoY, and YTD KPIs using CTEs and window functions.
- Designed a leadership KPI scorecard and Power BI-ready star schema to identify performance gaps by customer segment, region, warehouse, carrier, and service type.

## Data note

All companies, customers, orders, and operating results in this project are synthetic and created solely for portfolio use. They do not represent Metro Supply Chain or any other real company.

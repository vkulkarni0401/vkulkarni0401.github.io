# Power BI star schema

## Tables

- **Orders**: transaction fact table
- **Customers**: customer dimension
- **Warehouses**: warehouse dimension
- **Carriers**: carrier dimension
- **KPI Targets**: disconnected target table used by measures
- **Date**: calculated calendar table from `DAX_Measures.dax`

## Relationships

| From | To | Cardinality | Filter direction |
| --- | --- | --- | --- |
| Customers[customer_id] | Orders[customer_id] | One-to-many | Single |
| Warehouses[warehouse_id] | Orders[warehouse_id] | One-to-many | Single |
| Carriers[carrier_id] | Orders[carrier_id] | One-to-many | Single |
| Date[Date] | Orders[order_date] | One-to-many | Single |

Leave **KPI Targets** disconnected. Target measures filter it directly by metric name.

## Model settings

1. Mark `Date` as the date table using `Date[Date]`.
2. Sort `Date[Month]` by `Date[Month Number]`.
3. Sort `Date[Year Month]` by `Date[Month Start]`.
4. Hide technical key columns from the report view after relationships are complete.
5. Format revenue measures as Canadian dollars and rate measures as percentages with one decimal place.

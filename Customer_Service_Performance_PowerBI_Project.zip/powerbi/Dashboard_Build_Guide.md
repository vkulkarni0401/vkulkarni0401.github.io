# Power BI dashboard build guide

## Page 1: Leadership scorecard

Add six card visuals:

- YTD Revenue
- Service Level
- Retention Rate
- Churn Rate
- MoM Revenue Growth %
- YoY Revenue Growth %

Add a line chart with `Date[Month Start]` on the axis and `Delivered Revenue` as the value. Add a second line chart with Service Level, Retention Rate, and Churn Rate. Use slicers for Year, Region, Segment, and Service Type.

Recommended conditional colors:

- On target: green
- Within 2 percentage points of target: amber
- More than 2 percentage points below target or above the churn limit: red

## Page 2: Service operations

Add:

- Bar chart: Service Level by Warehouse
- Bar chart: Service Level by Carrier
- Matrix: Warehouse, Carrier, Delivered Orders, Late Orders, Service Level, Revenue
- Bar chart: Late Orders by Late Reason
- Slicers: Month, Region, Service Type

Use drill-through from warehouse or carrier to the underlying order list.

## Page 3: Customer retention

Add:

- Cards: Active Customers, Retained Customers, Churned Customers
- Line chart: Retention Rate and Churn Rate by Month
- Matrix: Segment and Region with Active Customers, Retention Rate, Churn Rate, and Revenue per Active Customer
- Table: churned customer list for the selected month

## Page 4: Front-line action view

Add a matrix by Warehouse and Carrier with Service Level Variance, Late Orders, Revenue, and Average Satisfaction. Sort by the largest negative service variance. Add a late-order detail table with Order ID, Customer, Promised Date, Delivery Date, Late Reason, and Order Value.

## Suggested project narrative

1. Start with the scorecard and identify KPIs that missed target.
2. Drill from the KPI to warehouse, carrier, service type, and region.
3. Quantify the revenue and customer population affected.
4. End with a front-line action list that managers can use in weekly reviews.

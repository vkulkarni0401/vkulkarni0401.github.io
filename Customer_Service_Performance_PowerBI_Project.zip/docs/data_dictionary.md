# Data dictionary

## customers.csv

| Field | Type | Description |
| --- | --- | --- |
| customer_id | text | Unique customer identifier |
| customer_name | text | Fictional customer display name |
| signup_date | date | Customer acquisition date |
| segment | text | Enterprise, Mid-Market, or Small Business |
| region | text | Canadian operating region |
| acquisition_channel | text | Direct Sales, Partner, or Digital |
| primary_service | text | Customer's primary logistics service |
| warehouse_id | text | Default serving warehouse |

## orders.csv

| Field | Type | Description |
| --- | --- | --- |
| order_id | text | Unique order identifier |
| customer_id | text | Foreign key to customers.csv |
| order_date | date | Date the order was placed |
| promised_date | date | Contracted delivery date |
| delivery_date | date | Actual delivery date; blank for cancelled orders |
| order_status | text | Delivered or Cancelled |
| service_type | text | Transportation, Warehousing, Fulfillment, or Last Mile |
| warehouse_id | text | Foreign key to warehouses.csv |
| carrier_id | text | Foreign key to carriers.csv |
| units | integer | Units handled on the order |
| order_value | decimal | Gross revenue associated with the order |
| delivery_cost | decimal | Direct service cost associated with the order |
| on_time_flag | integer | 1 for on-time delivery, 0 for late delivery, blank for cancellations |
| late_reason | text | On Time, Carrier Delay, Warehouse Capacity, Weather, Address Issue, or Cancelled |
| satisfaction_score | integer | Synthetic 1-5 customer satisfaction score; blank for cancellations |

## warehouses.csv

Provides warehouse names, provinces, and capacity tiers.

## carriers.csv

Provides carrier names and transportation modes.

## kpi_targets.csv

Provides KPI targets, comparison direction, cadence, and business definitions.

## monthly_kpi_results.csv

Provides independently calculated monthly results for validation and dashboard prototyping.

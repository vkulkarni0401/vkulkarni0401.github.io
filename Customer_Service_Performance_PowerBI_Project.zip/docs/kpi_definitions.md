# KPI definitions

## Service level

**Purpose:** Measures delivery reliability against the promised date.

**Formula:**

`On-time delivered orders / Total delivered orders`

Cancelled orders are excluded from both the numerator and denominator.

## Retention rate

**Purpose:** Measures the share of last month's active customers who remained active this month.

**Formula:**

`Customers active in both the prior and current month / Prior-month active customers`

An active customer has at least one delivered order during the month.

## Churn rate

**Purpose:** Measures the share of last month's active customers who placed no delivered order this month.

**Formula:**

`Prior-month active customers not active this month / Prior-month active customers`

Under this monthly activity definition, retention rate plus churn rate equals 100% when the prior-month population is available.

## Month-over-month revenue growth

**Formula:**

`Current-month delivered revenue / Previous-month delivered revenue - 1`

## Year-over-year revenue growth

**Formula:**

`Current-month delivered revenue / Revenue in the same month last year - 1`

## Year-to-date revenue

**Formula:**

`Sum of delivered revenue from January 1 through the reporting month`

The total resets at the beginning of each calendar year.

## Recommended targets

| KPI | Target | Status logic |
| --- | ---: | --- |
| Service level | 95% | On target when actual is at least 95% |
| Retention rate | 90% | On target when actual is at least 90% |
| Churn rate | 10% maximum | On target when actual is no more than 10% |
| MoM revenue growth | 2% | On target when actual is at least 2% |
| YoY revenue growth | 8% | On target when actual is at least 8% |
